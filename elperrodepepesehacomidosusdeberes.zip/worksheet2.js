//R1 E 1 //
/*
function obtenerfecha() {
fecha = new Date();
year = fecha.getFullYear();
month = fecha.getMonth();
day = fecha.getDate();
hour = fecha.getHours();
minute = fecha.getMinutes();
second = fecha.getSeconds();
return [year,month,day,hour,minute,second]
}
arr = obtenerfecha()
for (i of arr) {
  document.write(i + '</br>')
}
*/
//R1 E2//
/*
function mostrarResultados() {
fecha = new Date();
fechaHoy = [fecha.getFullYear(), fecha.getMonth(),fecha.getDate()]
fecha85 = [fecha]

}
*/l
